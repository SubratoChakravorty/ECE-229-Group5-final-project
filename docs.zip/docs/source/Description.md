# Description

Welcome to the documentation for our ECE229 project, Analysis of Ninth Grader’s Science Self Efficacy. This project focus on the analysis of students' self-efficiency, it provides a dashboard for visualiztion and further analysis for students and schools. Feel free to explore it at our page on [AWS](http://54.69.193.31).

## Dataset

This study employs public-use data from the High School Longitudinal Study of 2009 (HSLS:09). One important differencebetween HSLS:09 and previous studies is its focus on STEM education; one specific goal of the study is to gain an understanding of the factors that lead students to choose science, technology, engineering, and mathematics courses, majors, and careers.

## Authors

Ian Pegg, Subrato Chakravorty, Yan Sun, Daniel You, Heqian Lu, Kai Wang @ UCSD

```python
   _________    _________  ___________
  /   _____/   /   _____/  \_   _____/
  \_____  \    \_____  \    |    __)_ 
  /        \   /        \   |        \
  /_______  /  /_______  /  /_______  /
          \/           \/           \/ 

```
