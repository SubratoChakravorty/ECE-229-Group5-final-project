src package
===========

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   src.test
   src.ui

Submodules
----------

src.clean\_data module
----------------------

.. automodule:: src.clean_data
   :members:
   :undoc-members:
   :show-inheritance:

src.config module
-----------------

.. automodule:: src.config
   :members:
   :undoc-members:
   :show-inheritance:

src.multivariate\_methods module
--------------------------------

.. automodule:: src.multivariate_methods
   :members:
   :undoc-members:
   :show-inheritance:

src.univariate\_methods module
------------------------------

.. automodule:: src.univariate_methods
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: src
   :members:
   :undoc-members:
   :show-inheritance:
