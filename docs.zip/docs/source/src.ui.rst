src.ui package
==============

Submodules
----------

src.ui.dashboard module
-----------------------

.. automodule:: src.ui.dashboard
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: src.ui
   :members:
   :undoc-members:
   :show-inheritance:
